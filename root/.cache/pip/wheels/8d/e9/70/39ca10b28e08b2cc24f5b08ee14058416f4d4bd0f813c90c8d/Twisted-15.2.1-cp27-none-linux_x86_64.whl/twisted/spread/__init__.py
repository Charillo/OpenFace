# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Twisted Spread: Spreadable (Distributed) Computing.

@author: Glyph Lefkowitz
"""
