# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Instance Messenger, Pan-protocol chat client.
"""

