# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Twisted Names: DNS server and client implementations.
"""

from twisted.names._version import version
__version__ = version.short()
